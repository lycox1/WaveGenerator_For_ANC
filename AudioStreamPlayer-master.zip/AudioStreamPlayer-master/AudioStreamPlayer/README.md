MP3RadioStreamPlayer (Android Java)
=========

An MP3 online Stream player that uses MediaExtractor, MediaFormat, MediaCodec and AudioTrack meant as an alternative to using MediaPlayer.

User as a starting point.

Full explanation can be found here : http://www.piterwilson.com/blog/2014/03/15/mediacodec-mediaextractor-and-audiotrack-to-the-rescue/

This is an Eclipse project. 

License
----

MIT

